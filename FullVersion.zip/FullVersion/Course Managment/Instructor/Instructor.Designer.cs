﻿namespace Course_Managment.Instructor
{
    partial class instructorFrom
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.addInstBtn = new System.Windows.Forms.Button();
            this.addStudBtn = new System.Windows.Forms.Button();
            this.Welcome = new System.Windows.Forms.Label();
            this.showcrs = new System.Windows.Forms.Button();
            this.showstud = new System.Windows.Forms.Button();
            this.addCrs = new System.Windows.Forms.Button();
            this.delCrs = new System.Windows.Forms.Button();
            this.UpdCrs = new System.Windows.Forms.Button();
            this.UpdInstruc = new System.Windows.Forms.Button();
            this.addGrade = new System.Windows.Forms.Button();
            this.LogOut = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // addInstBtn
            // 
            this.addInstBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Italic);
            this.addInstBtn.Location = new System.Drawing.Point(241, 163);
            this.addInstBtn.Margin = new System.Windows.Forms.Padding(0);
            this.addInstBtn.Name = "addInstBtn";
            this.addInstBtn.Size = new System.Drawing.Size(275, 58);
            this.addInstBtn.TabIndex = 0;
            this.addInstBtn.Text = "Add Instructor";
            this.addInstBtn.UseVisualStyleBackColor = true;
            this.addInstBtn.Click += new System.EventHandler(this.addInstBtn_Click);
            // 
            // addStudBtn
            // 
            this.addStudBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Italic);
            this.addStudBtn.Location = new System.Drawing.Point(577, 163);
            this.addStudBtn.Margin = new System.Windows.Forms.Padding(0);
            this.addStudBtn.Name = "addStudBtn";
            this.addStudBtn.Size = new System.Drawing.Size(275, 58);
            this.addStudBtn.TabIndex = 1;
            this.addStudBtn.Text = "Add Student";
            this.addStudBtn.UseVisualStyleBackColor = true;
            this.addStudBtn.Click += new System.EventHandler(this.addStudBtn_Click);
            // 
            // Welcome
            // 
            this.Welcome.AutoSize = true;
            this.Welcome.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Italic);
            this.Welcome.ForeColor = System.Drawing.Color.SlateBlue;
            this.Welcome.Location = new System.Drawing.Point(316, 79);
            this.Welcome.Margin = new System.Windows.Forms.Padding(0);
            this.Welcome.Name = "Welcome";
            this.Welcome.Size = new System.Drawing.Size(407, 36);
            this.Welcome.TabIndex = 2;
            this.Welcome.Text = "INSTRUCTOR DASHBOARD";
            // 
            // showcrs
            // 
            this.showcrs.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Italic);
            this.showcrs.Location = new System.Drawing.Point(241, 315);
            this.showcrs.Margin = new System.Windows.Forms.Padding(0);
            this.showcrs.Name = "showcrs";
            this.showcrs.Size = new System.Drawing.Size(275, 58);
            this.showcrs.TabIndex = 3;
            this.showcrs.Text = "Show Course";
            this.showcrs.UseVisualStyleBackColor = true;
            this.showcrs.Click += new System.EventHandler(this.showcrs_Click);
            // 
            // showstud
            // 
            this.showstud.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Italic);
            this.showstud.Location = new System.Drawing.Point(577, 315);
            this.showstud.Margin = new System.Windows.Forms.Padding(0);
            this.showstud.Name = "showstud";
            this.showstud.Size = new System.Drawing.Size(275, 58);
            this.showstud.TabIndex = 4;
            this.showstud.Text = "Show Students";
            this.showstud.UseVisualStyleBackColor = true;
            this.showstud.Click += new System.EventHandler(this.showstud_Click);
            // 
            // addCrs
            // 
            this.addCrs.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Italic);
            this.addCrs.Location = new System.Drawing.Point(241, 235);
            this.addCrs.Margin = new System.Windows.Forms.Padding(0);
            this.addCrs.Name = "addCrs";
            this.addCrs.Size = new System.Drawing.Size(275, 58);
            this.addCrs.TabIndex = 7;
            this.addCrs.Text = "Add Course";
            this.addCrs.UseVisualStyleBackColor = true;
            this.addCrs.Click += new System.EventHandler(this.addCrs_Click);
            // 
            // delCrs
            // 
            this.delCrs.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Italic);
            this.delCrs.Location = new System.Drawing.Point(422, 492);
            this.delCrs.Margin = new System.Windows.Forms.Padding(0);
            this.delCrs.Name = "delCrs";
            this.delCrs.Size = new System.Drawing.Size(275, 66);
            this.delCrs.TabIndex = 8;
            this.delCrs.Text = "Delete Course";
            this.delCrs.UseVisualStyleBackColor = true;
            this.delCrs.Click += new System.EventHandler(this.delCrs_Click);
            // 
            // UpdCrs
            // 
            this.UpdCrs.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Italic);
            this.UpdCrs.Location = new System.Drawing.Point(241, 403);
            this.UpdCrs.Margin = new System.Windows.Forms.Padding(0);
            this.UpdCrs.Name = "UpdCrs";
            this.UpdCrs.Size = new System.Drawing.Size(275, 58);
            this.UpdCrs.TabIndex = 9;
            this.UpdCrs.Text = "Update Course";
            this.UpdCrs.UseVisualStyleBackColor = true;
            this.UpdCrs.Click += new System.EventHandler(this.UpdCrs_Click);
            // 
            // UpdInstruc
            // 
            this.UpdInstruc.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Italic);
            this.UpdInstruc.Location = new System.Drawing.Point(577, 395);
            this.UpdInstruc.Margin = new System.Windows.Forms.Padding(0);
            this.UpdInstruc.Name = "UpdInstruc";
            this.UpdInstruc.Size = new System.Drawing.Size(275, 66);
            this.UpdInstruc.TabIndex = 10;
            this.UpdInstruc.Text = "Update Instrcutor";
            this.UpdInstruc.UseVisualStyleBackColor = true;
            this.UpdInstruc.Click += new System.EventHandler(this.UpdInstruc_Click);
            // 
            // addGrade
            // 
            this.addGrade.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Italic);
            this.addGrade.Location = new System.Drawing.Point(577, 231);
            this.addGrade.Margin = new System.Windows.Forms.Padding(0);
            this.addGrade.Name = "addGrade";
            this.addGrade.Size = new System.Drawing.Size(275, 66);
            this.addGrade.TabIndex = 11;
            this.addGrade.Text = "Add Grade";
            this.addGrade.UseVisualStyleBackColor = true;
            this.addGrade.Click += new System.EventHandler(this.addGrade_Click);
            // 
            // LogOut
            // 
            this.LogOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Italic);
            this.LogOut.ForeColor = System.Drawing.Color.OrangeRed;
            this.LogOut.Location = new System.Drawing.Point(909, 32);
            this.LogOut.Margin = new System.Windows.Forms.Padding(0);
            this.LogOut.Name = "LogOut";
            this.LogOut.Size = new System.Drawing.Size(132, 45);
            this.LogOut.TabIndex = 12;
            this.LogOut.Text = "Log Out";
            this.LogOut.UseVisualStyleBackColor = true;
            this.LogOut.Click += new System.EventHandler(this.LogOut_Click);
            // 
            // instructorFrom
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(1222, 722);
            this.Controls.Add(this.LogOut);
            this.Controls.Add(this.addGrade);
            this.Controls.Add(this.UpdInstruc);
            this.Controls.Add(this.UpdCrs);
            this.Controls.Add(this.delCrs);
            this.Controls.Add(this.addCrs);
            this.Controls.Add(this.showstud);
            this.Controls.Add(this.showcrs);
            this.Controls.Add(this.Welcome);
            this.Controls.Add(this.addStudBtn);
            this.Controls.Add(this.addInstBtn);
            this.Margin = new System.Windows.Forms.Padding(0);
            this.Name = "instructorFrom";
            this.Text = "Instructor";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button addInstBtn;
        private System.Windows.Forms.Button addStudBtn;
        private System.Windows.Forms.Label Welcome;
        private System.Windows.Forms.Button showcrs;
        private System.Windows.Forms.Button showstud;
        private System.Windows.Forms.Button addCrs;
        private System.Windows.Forms.Button delCrs;
        private System.Windows.Forms.Button UpdCrs;
        private System.Windows.Forms.Button UpdInstruc;
        private System.Windows.Forms.Button addGrade;
        private System.Windows.Forms.Button LogOut;
    }
}